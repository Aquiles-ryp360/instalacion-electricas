# Biblioteca CAD DGE de consulta

- MT: abrir cad/BIBLIOTECA_DGE_MT_COMPLETA.dwg o un DXF del directorio cad/MT.
- BT: abrir cad/BIBLIOTECA_DGE_BT_COMPLETA.dwg; la lámina022 aprobada de 2019 está separada en cad/BT.
- Símbolos: cad/SIMBOLOGIA_DGE_SECCION_9.dwg o DXF. Insertar bloques por código DGE.

Las fuentes PDF y los catálogos por código se incluyen. Los CAD son derivados de esas fuentes, no archivos emitidos por MINEM. Las hojas usan mm de papel, sin coordenadas geográficas; las cotas originales prevalecen sobre medidas del dibujo. MT proviene de escaneos: letras y cotas son contornos editables, no TEXT/DIMENSION.

La plantilla original de terceros está en terceros/esolutions con las condiciones del fabricante. No adoptar automáticamente materiales de madera como estructuras CAC. Ver README y fuentes para límites y aplicación.

El DWG maestro MT se ofrece como descarga separada junto al ZIP en GitHub, por su tamaño. El ZIP contiene los 102 DXF individuales MT completos.
